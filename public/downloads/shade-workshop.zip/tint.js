export function makeRenderer(canvas) {
  const gl = canvas.getContext("webgl2", { preserveDrawingBuffer: true });
  if (!gl) throw new Error("這份練習需要 WebGL2。");
  function compile(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(shader));
    return shader;
  }
  const program = gl.createProgram();
  gl.attachShader(program, compile(gl.VERTEX_SHADER, `#version 300 es
    out vec2 uv;
    void main() {
      vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
      uv = vec2(corner.x, 1.0-corner.y);
      gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
    }`));
  gl.attachShader(program, compile(gl.FRAGMENT_SHADER, `#version 300 es
    precision mediump float;
    in vec2 uv; out vec4 pixel;
    uniform sampler2D photo; uniform sampler2D mask;
    uniform float strength;
    void main(){
      vec3 original = texture(photo, uv).rgb;
      float weight = strength * texture(mask, uv).r;
      pixel = vec4(mix(original, vec3(0.72, 0.08, 0.28), weight), 1);
    }`));
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(program));
  gl.useProgram(program);
  const textures = ["photo", "mask"].map((name, i) => {
    gl.uniform1i(gl.getUniformLocation(program, name), i);
    const texture = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0 + i);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return texture;
  });
  return (photo, mask, strength) => {
    gl.viewport(0, 0, canvas.width, canvas.height);
    [photo, mask].forEach((source, i) => {
      gl.activeTexture(gl.TEXTURE0 + i);
      gl.bindTexture(gl.TEXTURE_2D, textures[i]);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    });
    gl.uniform1f(gl.getUniformLocation(program, "strength"), strength);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  };
}
