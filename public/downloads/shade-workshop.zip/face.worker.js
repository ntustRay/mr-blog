import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";
let model;
self.onmessage = async ({ data: { id, bitmap, base } }) => {
  try {
    if (!model) {
      const files = await FilesetResolver.forVisionTasks(new URL("wasm", base).href, true);
      model = await FaceLandmarker.createFromOptions(files, {
        baseOptions: { modelAssetPath: new URL("models/face_landmarker.task", base).href, delegate: "CPU" },
        runningMode: "IMAGE", numFaces: 1
      });
    }
    const points = model.detect(bitmap).faceLandmarks[0] ?? [];
    self.postMessage({ id, points });
  } catch (error) {
    self.postMessage({ id, error: String(error) });
  } finally {
    bitmap.close();
  }
};
