import { cp, mkdir, writeFile } from "node:fs/promises";
const source = new URL("https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task");
await mkdir("public/models", { recursive: true });
await cp("node_modules/@mediapipe/tasks-vision/wasm", "public/wasm", { recursive: true });
const response = await fetch(source);
if (!response.ok) throw new Error("Model download failed: " + response.status);
await writeFile("public/models/face_landmarker.task", new Uint8Array(await response.arrayBuffer()));
console.log("Ready: public/models/face_landmarker.task and public/wasm/");
