import { makeRenderer } from "./tint.js";
const get = id => document.getElementById(id);
const photo = get("input"), mask = get("mask"), result = get("output");
const photoCtx = photo.getContext("2d"), maskCtx = mask.getContext("2d");
const render = makeRenderer(result);
let job = null, generation = 0, stream = null, cameraRequest = 0;
function show(message) { get("status").textContent = message; }
function draw() { render(photo, mask, get("strength").valueAsNumber / 100); }
function clip() { result.style.clipPath = "inset(0 0 0 " + get("split").value + "%)"; }
function clearMask() {
  maskCtx.fillStyle = "black";
  maskCtx.fillRect(0, 0, mask.width, mask.height);
}
function seed() {
  const gradient = photoCtx.createLinearGradient(0,0,360,220);
  gradient.addColorStop(0, "#e8b896"); gradient.addColorStop(1, "#77565b");
  photoCtx.fillStyle = gradient; photoCtx.fillRect(0, 0, 360, 220);
  clearMask();
  const lips = new Path2D();
  lips.ellipse(180, 110, 83, 32, 0, 0, 2 * Math.PI);
  lips.moveTo(228, 110); lips.ellipse(180, 110, 48, 6, 0, 0, 2 * Math.PI);
  maskCtx.fillStyle = "white"; maskCtx.fill(lips, "evenodd"); draw(); clip();
}
const outer = [61,40,37,0,267,270,291,321,314,17,84,91];
const inner = [78,81,13,311,308,402,14,178];
function faceMask(points) {
  clearMask();
  if (points.length) {
    const lips = new Path2D();
    for (const ring of [outer, inner]) {
      ring.forEach((index, i) => {
        const p = points[index];
        if (i === 0) lips.moveTo(p.x * mask.width, p.y * mask.height);
        else lips.lineTo(p.x * mask.width, p.y * mask.height);
      });
      lips.closePath();
    }
    maskCtx.fillStyle = "white"; maskCtx.fill(lips, "evenodd");
  }
  draw();
}
async function inspect(source) {
  const id = ++generation;
  job?.terminate(); job = null;
  const bitmap = await createImageBitmap(source);
  if (id !== generation) { bitmap.close(); return; }
  const scale = Math.min(1, 720 / Math.max(bitmap.width, bitmap.height));
  for (const layer of [photo, mask, result]) {
    layer.width = Math.max(1, Math.round(bitmap.width * scale));
    layer.height = Math.max(1, Math.round(bitmap.height * scale));
  }
  photoCtx.drawImage(bitmap, 0, 0, photo.width, photo.height);
  bitmap.close(); clearMask(); draw(); show("正在定位，請稍候");
  const copy = await createImageBitmap(photo);
  if (id !== generation) { copy.close(); return; }
  const current = new Worker(new URL("./face.worker.js", import.meta.url), { type: "module" });
  job = current;
  current.onmessage = ({ data }) => {
    if (data.id !== generation) return;
    if (data.error) show("模型載入失敗：" + data.error);
    else { faceMask(data.points); show(data.points.length ? "已定位，可比較和下載。" : "找不到臉，請換正面人像。"); }
    current.terminate(); job = null;
  };
  current.onerror = event => { if (id === generation) show(event.message); current.terminate(); };
  current.postMessage({ id, bitmap: copy, base: new URL(import.meta.env.BASE_URL, location.href).href }, [copy]);
}
function stopCamera() {
  cameraRequest++;
  stream?.getTracks().forEach(track => track.stop());
  stream = null; get("camera").srcObject = null; get("camera").hidden = true;
  get("take").disabled = true; get("stop").disabled = true;
}
get("file").onchange = async () => {
  const file = get("file").files[0];
  if (file) { stopCamera(); try { await inspect(file); } catch (e) { show(String(e)); } }
};
get("cameraOn").onclick = async () => {
  stopCamera();
  const request = cameraRequest;
  try {
    const media = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    if (request !== cameraRequest) { media.getTracks().forEach(track => track.stop()); return; }
    stream = media; const video = get("camera"); video.srcObject = media; video.hidden = false;
    await video.play();
    if (request === cameraRequest) { get("take").disabled = false; get("stop").disabled = false; }
  } catch (e) { if (request === cameraRequest) { stopCamera(); show(String(e)); } }
};
get("take").onclick = () => inspect(get("camera")).catch(e => show(String(e)));
get("stop").onclick = stopCamera;
get("strength").oninput = draw; get("split").oninput = clip;
get("download").onclick = () => {
  draw();
  result.toBlob(blob => {
    if (!blob) { show("無法產生 PNG。"); return; }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "shade-practice.png"; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }, "image/png");
};
window.addEventListener("pagehide", () => { generation++; job?.terminate(); stopCamera(); });
seed();
