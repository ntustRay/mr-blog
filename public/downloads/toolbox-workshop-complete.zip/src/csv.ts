export function csvToRecords(input: string) {
  const rows: string[][] = [];
  let row: string[] = [], field = '', quoted = false, closed = false;
  const source = input.replace(/^\uFEFF/, '');
  if (!source) throw new Error('缺少欄名');
  for (let i = 0; i < source.length; i++) {
    const c = source[i];
    if (quoted) {
      if (c !== '"') field += c;
      else if (source[i + 1] === '"') { field += '"'; i++; }
      else { quoted = false; closed = true; }
    } else if (c === ',' || c === '\n' || c === '\r') {
      row.push(field); field = ''; closed = false;
      if (c !== ',') {
        if (c === '\r' && source[i + 1] === '\n') i++;
        rows.push(row); row = [];
      }
    } else if (c === '"' && !field && !closed) {
      quoted = true;
    } else {
      if (closed || c === '"') throw new Error('引號位置錯誤');
      field += c;
    }
  }
  if (quoted) throw new Error('引號未關閉');
  if (row.length || field || closed || !/[\r\n]$/.test(source)) {
    rows.push([...row, field]);
  }
  const [headers, ...data] = rows;
  if (headers.some(h => !h) || new Set(headers).size !== headers.length)
    throw new Error('欄名不可空白或重複');
  const records = data.map(row => {
    if (row.length !== headers.length) throw new Error('欄位數不符');
    return Object.fromEntries(headers.map((h, i) => [h, row[i]]));
  });
  return { headers, records };
}

export function toCsv(headers: string[], records: Record<string, string>[]) {
  const escape = (s: string) => /[",\r\n]/.test(s)
    ? '"' + s.replaceAll('"', '""') + '"' : s;
  return [headers, ...records.map(row => headers.map(h => row[h]))]
    .map(row => row.map(escape).join(',')).join('\r\n');
}
