import React, { useState } from 'react';
import { diffLines } from 'diff';

export default function Diff() {
  const [before, setBefore] = useState('狀態：驗收中\n負責人：開發者');
  const [after, setAfter] = useState('狀態：已部署\n負責人：開發者');
  const [trim, setTrim] = useState(false);
  function normalize(input: string) {
    const text = input.replace(/\r\n?/g, '\n');
    return trim ? text.split('\n').map(line => line.trim()).join('\n') : text;
  }
  const parts = diffLines(normalize(before), normalize(after));
  return <><h1>逐行比對</h1>
    <label>原文<textarea value={before} onChange={e => setBefore(e.target.value)} /></label>
    <label>新版<textarea value={after} onChange={e => setAfter(e.target.value)} /></label>
    <label><input type="checkbox" checked={trim}
      onChange={e => setTrim(e.target.checked)} />忽略行首與行尾空白</label>
    <pre>{parts.map(part => {
      const mark = part.added ? '+ ' : part.removed ? '− ' : '  ';
      return part.value.replace(/\n$/, '').split('\n').map(line => mark + line).join('\n');
    }).join('\n')}</pre></>;
}
