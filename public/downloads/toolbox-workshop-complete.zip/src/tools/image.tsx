import React, { useEffect, useState } from 'react';
import { encode } from '../encode';

export default function ImageTool() {
  const [file, setFile] = useState<File | null>(null);
  const [jpeg, setJpeg] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ url: string; ext: string } | null>(null);
  const [error, setError] = useState('');
  useEffect(() => () => { if (result) URL.revokeObjectURL(result.url); }, [result]);
  async function run() {
    if (!file) return;
    setBusy(true); setError(''); setResult(null);
    try {
      const blob = await encode(file, jpeg ? 'image/jpeg' : 'image/webp');
      setResult({ url: URL.createObjectURL(blob), ext: jpeg ? 'jpg' : 'webp' });
    } catch (e) { setError(e instanceof Error ? e.message : '轉檔失敗'); }
    finally { setBusy(false); }
  }
  return <><h1>圖片轉檔</h1>
    <label>原圖 <input disabled={busy} type="file" accept="image/png,image/jpeg,image/webp"
      onChange={e => { setFile(e.target.files?.[0] ?? null); setResult(null); }} /></label>
    <label><input type="checkbox" disabled={busy} checked={jpeg}
      onChange={e => { setJpeg(e.target.checked); setResult(null); }} />輸出白底 JPG（預設 WebP）</label>
    <button disabled={busy || !file} onClick={run}>轉檔</button>
    {result && <output><img src={result.url} alt="轉檔預覽" /><br/>
      <a href={result.url} download={`result.${result.ext}`}>下載 {result.ext}</a></output>}
    <p role="status">{error}</p></>;
}
