import React, { useState } from 'react';
import { csvToRecords, toCsv } from '../csv';
const sample = 'id,name,note\n00123,小林,"到貨,待驗收"\n00007,小陳,';
export default function Csv() {
  const [text, setText] = useState(sample);
  const [result, setResult] = useState('');
  function run() {
    try {
      const { headers, records } = csvToRecords(text);
      setResult(JSON.stringify(records, null, 2) + '\n\n' + toCsv(headers, records));
    } catch (e) { setResult(e instanceof Error ? e.message : '格式錯誤'); }
  }
  return <><h1>CSV 來回轉換</h1>
    <label>輸入 CSV<textarea value={text} onChange={e => setText(e.target.value)} /></label>
    <button onClick={run}>轉換並還原</button><pre>{result}</pre></>;
}
