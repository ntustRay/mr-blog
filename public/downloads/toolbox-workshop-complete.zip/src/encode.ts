export async function encode(file: File, mime: 'image/webp' | 'image/jpeg') {
  const image = await createImageBitmap(file);
  try {
    const canvas = document.createElement('canvas');
    canvas.width = image.width; canvas.height = image.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('無法建立 Canvas');
    if (mime === 'image/jpeg') {
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.drawImage(image, 0, 0);
    const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, mime, 0.9));
    if (!blob || blob.type !== mime) throw new Error('瀏覽器不支援此輸出格式');
    return blob;
  } finally { image.close(); }
}
