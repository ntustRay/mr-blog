import React from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

import { modules } from './tools';
const names = Object.keys(modules).map(path => path.split('/').pop()!.replace('.tsx', ''));
const key = new URLSearchParams(location.search).get('tool') ?? 'csv';
const Tool = modules[`./tools/${key}.tsx`]?.default;
createRoot(document.getElementById('root')!).render(<main>
  <nav>{names.map(name => <a key={name} href={`?tool=${name}`}>{name}</a>)}</nav>
  {Tool ? <Tool /> : <p>請選擇上方工具。</p>}
</main>);
