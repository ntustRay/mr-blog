import type { ComponentType } from 'react';
export const modules = import.meta.glob<{ default: ComponentType }>(
  './tools/*.tsx', { eager: true }
);
