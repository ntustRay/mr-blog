import { deepEqual } from "node:assert/strict";
import { test } from "node:test";
import { screenStocks } from "./stock-fixture.ts";

test("保留和名稱或代號相符的公司", () => {
  deepEqual(screenStocks("材料", null).map(row => row.code), ["9002"]);
  deepEqual(screenStocks("missing", null), []);
});
test("套用本益比上限時，缺值不能當成零", () => {
  deepEqual(screenStocks("", 15).map(row => row.code), ["9001"]);
  deepEqual(screenStocks("9002", 15), []);
});
