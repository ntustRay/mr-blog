export const marketDate = "2026-01-02";

export type Stock = {
  code: string;
  name: string;
  price: number;
  pe: number | null;
};

export const stocks: Stock[] = [
  { code: "9001", name: "範例電子", price: 48, pe: 12 },
  { code: "9002", name: "範例材料", price: 30, pe: null },
];

export function screenStocks(query: string, maxPe: number | null): Stock[] {
  const term = query.trim();
  return stocks.filter(stock =>
    (stock.code.includes(term) || stock.name.includes(term)) &&
    (maxPe === null || (stock.pe !== null && stock.pe <= maxPe))
  );
}
