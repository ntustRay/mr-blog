import { marketDate, screenStocks } from "@/lib/stock-fixture";

export function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const raw = params.get("per_max")?.trim();
  const limit = raw ? Number(raw) : null;
  if (limit !== null && (!Number.isFinite(limit) || limit < 0)) {
    return Response.json({ error: "per_max 必須是非負數" }, { status: 400 });
  }
  const rows = screenStocks(params.get("q") ?? "", limit);
  return Response.json({
    data: { total: rows.length, rows },
    meta: { source: "fixture", fixture: true, date: marketDate },
    error: null,
  });
}
