import { marketDate, screenStocks } from "@/lib/stock-fixture";

type Search = { q?: string; per_max?: string };

export default async function Page({ searchParams }: { searchParams: Promise<Search> }) {
  const { q = "", per_max = "" } = await searchParams;
  const limit = per_max.trim() ? Number(per_max) : null;
  const valid = limit === null || (Number.isFinite(limit) && limit >= 0);
  const rows = valid ? screenStocks(q, limit) : [];
  return <main>
    <p>工程師選股網練習 · 固定測試資料</p>
    <h1>股票查詢</h1>
    <p>資料日期 {marketDate}。兩家公司皆為虛構。</p>
    <form>
      <label>代號或名稱<input name="q" defaultValue={q} /></label>
      <label>本益比上限<input name="per_max" defaultValue={per_max} type="number" min="0" step="any" /></label>
      <button>查詢</button>
    </form>
    {valid ? <p>共 {rows.length} 筆</p> : <p role="alert">請輸入非負數。</p>}
    <table><thead><tr><th>代號</th><th>公司</th><th>價格</th><th>本益比</th></tr></thead>
      <tbody>{rows.map(stock => <tr key={stock.code}>
        <td>{stock.code}</td><td>{stock.name}</td><td>{stock.price}</td><td>{stock.pe ?? "缺值"}</td>
      </tr>)}</tbody>
    </table>
  </main>;
}
