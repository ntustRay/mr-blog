# 選股網練習

使用 Node.js 24。在含 package.json 的目錄執行 `npm install`、`npm test`、`npm run dev`。開啟終端機顯示的本機網址。使用兩筆固定的虛構公司資料；行情與價格僅供程式驗收。

- `/?q=9001` 應只列出範例電子。
- `/api/v1/screener?per_max=15` 應得到一筆資料，`meta.source` 為 `fixture`。
- 新增第三家公司時，先改 `src/lib/stock-fixture.ts`，再在旁邊的測試加上一組查詢。
- `npm run build` 產生 Next.js build。Vercel 匯入此資料夾所在的 Git repository，選 Next.js，使用 fixture 首頁時不需要設定遠端服務。
- `src/lib/supabase/server.ts` 與 `src/proxy.ts` 供〈設定 Supabase 註冊、登入與寄信〉新增 Email 登入頁時使用。先將 `.env.example` 複製為 `.env.local` 並填自己測試專案的資料，再走文章的登入與 callback 步驟。
