import page from './index.html' with { type: 'text' };

type SocketData = { room: string };
const rooms = new Map<string, string[]>();

const server = Bun.serve<SocketData>({
  hostname: '127.0.0.1',
  port: 4178,
  fetch(req, server) {
    const url = new URL(req.url);
    if (url.pathname === '/') return new Response(page, {
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
    if (url.pathname !== '/room') return new Response('Not found', { status: 404 });
    const room = url.searchParams.get('id') ?? '';
    if (!/^[a-z0-9-]{1,32}$/.test(room)) return new Response('Invalid room', { status: 400 });
    if (req.headers.get('origin') !== url.origin) return new Response('Invalid origin', { status: 403 });
    if (server.upgrade(req, { data: { room } })) return;
    return new Response('WebSocket required', { status: 426 });
  },
  websocket: {
    maxPayloadLength: 256,
    open(ws) {
      ws.subscribe(ws.data.room);
      ws.send(JSON.stringify(rooms.get(ws.data.room) ?? []));
    },
    message(ws, data) {
      if (typeof data !== 'string') return;
      const word = data.trim();
      if (!word || word.length > 32 || /\s/.test(word)) return;
      const room = ws.data.room;
      const words = rooms.get(room) ?? [];
      if (words.length >= 50) return;
      words.push(word);
      rooms.set(room, words);
      server.publish(room, JSON.stringify(words));
    },
  },
});
console.log(server.url.href);
