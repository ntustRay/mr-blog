import type { DateTimeRangeValue } from '@ntustray/react-datetime-range-picker';

const events = [
  { label: '12:30 UTC', at: Date.UTC(2026, 7, 9, 12, 30) },
  { label: '13:00 UTC', at: Date.UTC(2026, 7, 9, 13) },
  { label: '13:15 UTC', at: Date.UTC(2026, 7, 9, 13, 15) },
];

export function eventsIn({ startTimestamp, endTimestamp }: DateTimeRangeValue) {
  if (startTimestamp === null || endTimestamp === null) return [];
  return events.filter(({ at }) => startTimestamp <= at && at < endTimestamp);
}
