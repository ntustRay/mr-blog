import { useState } from 'react';
import {
  DateTimeRangePicker, type DateTimeRangeValue,
} from '@ntustray/react-datetime-range-picker';
import '@ntustray/react-datetime-range-picker/styles.css';
import { eventsIn } from './events';

const initial = {
  startTimestamp: Date.UTC(2026, 7, 9, 12),
  endTimestamp: Date.UTC(2026, 7, 9, 13, 30),
};

export default function App() {
  const [draft, setDraft] = useState<DateTimeRangeValue>(initial);
  const [query, setQuery] = useState<DateTimeRangeValue>(initial);
  return <main>
    <DateTimeRangePicker value={draft} onChange={setDraft}
      onCommit={setQuery} locale="zh-TW" timezone="UTC" />
    <ul>{eventsIn(query).map(event => <li key={event.at}>{event.label}</li>)}</ul>
  </main>;
}
