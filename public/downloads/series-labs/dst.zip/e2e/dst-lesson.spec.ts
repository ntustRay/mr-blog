import { expect, test } from '@playwright/test';

test('跳過的 02:30 顯示錯誤', async ({ page }) => {
  await page.goto('/');
  const card = page.locator('.scenario-card').filter({ hasText: 'Spring-forward gap' });
  await card.getByRole('button', { name: 'Open calendar' }).click();
  const start = card.getByTestId('dtrp-start-input');
  await start.fill('2024/03/10 02:30:00');
  await start.blur();
  const dialog = page.getByRole('dialog', { name: 'DST gap example' });
  await expect(dialog).toContainText('This local time does not exist.');
});

test('重複的 01:30 有兩個 offset 可選', async ({ page }) => {
  await page.goto('/');
  const card = page.locator('.scenario-card').filter({ hasText: 'Fall-back overlap' });
  await card.getByRole('button', { name: 'Open calendar' }).click();
  const start = card.getByTestId('dtrp-start-input');
  await start.fill('2024/11/03 01:30:00');
  await start.blur();
  const dialog = page.getByRole('dialog', { name: 'DST overlap example' });
  const offsets = dialog.getByRole('combobox', { name: 'Start UTC offset' });
  await expect(offsets).toBeVisible();
  await expect(offsets.locator('option').filter({ hasText: '-04:00' })).toHaveCount(1);
  await expect(offsets.locator('option').filter({ hasText: '-05:00' })).toHaveCount(1);
});
