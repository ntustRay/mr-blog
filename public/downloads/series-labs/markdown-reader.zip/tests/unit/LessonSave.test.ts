import { expect, it, vi } from 'vitest';
import { open } from '@tauri-apps/plugin-dialog';
import { readFile, size, writeFile } from '@tauri-apps/plugin-fs';
import { FileService } from '../../src/services/FileService';

vi.mock('@tauri-apps/plugin-dialog');
vi.mock('@tauri-apps/plugin-fs');

it('keeps the draft after a write error and saves the retry', async () => {
  vi.mocked(open).mockResolvedValue('demo.md');
  vi.mocked(size).mockResolvedValue(0);
  vi.mocked(readFile).mockResolvedValue(new Uint8Array());
  vi.mocked(writeFile)
    .mockRejectedValueOnce(new Error('read only'))
    .mockResolvedValueOnce(undefined);

  const service = new FileService();
  await service.openDocument();
  service.updateDraft('# Trip notes');
  await expect(service.saveDocument()).rejects.toThrow('read only');
  expect(service.getCurrentDocument()).toMatchObject({
    savedContent: '', draftContent: '# Trip notes',
  });

  await expect(service.saveDocument()).resolves.toMatchObject({
    savedContent: '# Trip notes', draftContent: '# Trip notes',
  });
  expect(writeFile).toHaveBeenLastCalledWith(
    'demo.md', new TextEncoder().encode('# Trip notes'),
  );
});
