use eframe::egui;
use rust_auto_shutdown::{Mode, Timer, format_remaining};
use std::time::{Duration, Instant};

#[derive(Default)]
struct Reminder {
    timer: Timer,
    status: String,
}

impl eframe::App for Reminder {
    fn update(&mut self, ctx: &egui::Context, _: &mut eframe::Frame) {
        let now = Instant::now();
        egui::CentralPanel::default().show(ctx, |ui| {
            if let Some(left) = self.timer.remaining(now) {
                ui.heading(format_remaining(left));
                if ui.button("+10 min").clicked() {
                    if let Err(message) = self.timer.extend(now, Duration::from_secs(600)) {
                        self.status = message;
                    }
                }
                if ui.button("Cancel").clicked() {
                    self.timer.cancel();
                    self.status = "Cancelled".into();
                }
            } else if ui.button("Start 3 min").clicked() {
                self.status = match self.timer.start(now, Duration::from_secs(180), Mode::Simulation) {
                    Ok(()) => "Running".into(),
                    Err(message) => message,
                };
            }
            if self.timer.poll(now, || Ok(())).is_some() {
                self.status = "Finished (simulation)".into();
            }
            ui.label(&self.status);
        });
        ctx.request_repaint_after(Duration::from_millis(200));
    }
}

fn main() -> eframe::Result {
    eframe::run_native("Reminder lab", eframe::NativeOptions::default(),
        Box::new(|_| Ok(Box::new(Reminder::default()))))
}
