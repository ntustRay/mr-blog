use rust_auto_shutdown::{Mode, Timer};
use std::time::{Duration, Instant};

#[test]
fn postpone_then_cancel() {
    let start = Instant::now();
    let mut timer = Timer::default();
    timer.start(start, Duration::from_secs(180), Mode::Simulation).unwrap();

    let clicked = start + Duration::from_secs(60);
    let remaining = timer.extend(clicked, Duration::from_secs(600)).unwrap();
    assert_eq!(remaining, Duration::from_secs(720));
    assert!(timer.cancel());
    assert_eq!(timer.remaining(clicked), None);
    assert!(timer.poll(clicked + remaining, || panic!("unexpected action")).is_none());
}
