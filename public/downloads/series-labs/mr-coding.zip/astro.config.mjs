import { defineConfig } from 'astro/config';

export default defineConfig({ base: '/series-workshop', trailingSlash: 'always' });
