import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const lessons = defineCollection({
  loader: glob({ base: './src/lessons', pattern: '*.md' }),
  schema: z.object({ title: z.string(), seriesOrder: z.number().int().positive() }),
});

export const collections = { lessons };
