---
title: 在本機預覽
seriesOrder: 1
---

執行 `npm run dev`，在瀏覽器開啟系列首頁。
