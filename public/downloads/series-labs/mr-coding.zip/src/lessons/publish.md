---
title: 發到 GitHub Pages
seriesOrder: 2
---

先建置 HTML，再把產物交給 GitHub Pages。
