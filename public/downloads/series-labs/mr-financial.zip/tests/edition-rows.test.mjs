import assert from 'node:assert/strict';
import test from 'node:test';
import { editionRows } from '../src/utils/edition-rows.mjs';

test('同日合併、缺版留空、日期倒序、略過一般文章', () => {
  const tw = 'finance-2026-11-25-taiwan';
  const intl = 'finance-2026-11-25-global';
  const last = 'finance-2026-11-24-global';
  assert.deepEqual(editionRows([last, intl, 'housing-note', tw]), [
    { date: '2026-11-25', taiwan: tw, global: intl },
    { date: '2026-11-24', taiwan: null, global: last },
  ]);
});
