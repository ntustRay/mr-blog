export function editionRows(ids) {
  const dates = new Map();
  for (const id of ids) {
    const match = /^finance-(\d{4}-\d{2}-\d{2})-(taiwan|global)$/.exec(id);
    if (!match) continue;
    const [, date, region] = match;
    const row = dates.get(date) ?? { date, taiwan: null, global: null };
    row[region] = id;
    dates.set(date, row);
  }
  return [...dates.values()].sort((a, b) => b.date.localeCompare(a.date));
}
