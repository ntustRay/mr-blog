# [Guide] 工程師選股網 03：讓 GitHub Actions 更新股票資料

[查看線上最新版](https://ntustray.github.io/mr-blog/posts/engineer-stock-03-actions/) · [離線目錄](../README.md)

完成這篇：看懂一次資料更新，分辨「Workflow 成功」「資料有更新」「資料是哪一天」。

![資料發布流程示意：驗證與必要來源成功才更新 data；失敗保留前版 SHA。](../images/03-actions-flow.svg)

## 先在自己的 fork 寫一個能手動執行的工作流程

在 [engineer-stock-data](https://github.com/ntustRay/engineer-stock-data) 按 **Fork**。進自己的 fork，在 **Actions** 分頁啟用 workflows。透過 **Add file → Create new file** 新增以下檔案，commit 到自己的預設分支。這個練習只跑 repo 內的固定測資。

```yaml title=".github/workflows/fixture-ci.yml"
name: Stock fixture test
on: workflow_dispatch
permissions:
  contents: read
jobs:
  fixture:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: oven-sh/setup-bun@v2
        with:
          bun-version: "1.4.4"
      - run: bun install --frozen-lockfile
      - run: bun test tests
```

打開 **Actions → Stock fixture test → Run workflow**。選預設分支，打開新 run 的 **fixture** job，展開最後一個 step，應看到 Bun 列出的測試結果。若左側沒出現名稱，先核對檔案位置和 default branch。接下來讀同一 repo 的正式行情 workflow，辨認它從哪一步開始需要寫入權限。

## 1. 開啟既有 Workflow

進入資料 Repo 的 **Actions → Publish data**。對照 `.github/workflows/publish-data.yml`。

![GitHub Actions 實拍；這是既有執行紀錄，非本次重新觸發發布。](../images/03-actions.webp)

有寫入權限時，點 **Run workflow**，branch 選 `main`。`targetDate` 先留空、`forceRefresh` 保持 false，再送出。本文沒有代你觸發股票更新；這一步留給自己操作。

## 2. 看兩個 job 的責任

| Job | 執行內容 | 成功後 |
| --- | --- | --- |
| `validate` | 安裝、Biome、TypeScript、unit tests | 才會開始 `publish` job |
| `publish` | 讀官方來源、驗證快照、發布 | 可能更新 `data` branch，也可能合法略過 |

`publish` 透過 `needs: validate` 等待檢查；只有這個 job 有 `contents: write`。`concurrency` 搭配發布程式的 lease 檢查，避免更新互相覆蓋。

## 3. 對照排程與台北時間

既有設定使用 UTC：

```yaml title=".github/workflows/publish-data.yml（節錄）"
schedule:
  - cron: '10 11 * * 1-5'
  - cron: '10 14 * * 1-5'
```

| UTC | 台北時間 |
| --- | --- |
| 週一至週五 11:10 | 週一至週五 19:10 |
| 週一至週五 14:10 | 週一至週五 22:10 |

[GitHub 排程可能延遲](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule)；來源日期、交易日曆仍由程式檢查。排程到點不代表來源已經更新。

## 4. 打開執行紀錄中的 JSON

在 publish step 或 Summary 找：

| 欄位／訊息 | 代表什麼 |
| --- | --- |
| `asOfDate` | 行情所屬交易日 |
| `snapshotId` | 這批資料的識別 |
| `commitSha` | 發布後網站會讀取的版本 |
| `stage: skip`、`reason: unchanged` | 內容相同，這次不重發 |
| `reason: non_trading_day` | 交易日判斷後略過 |

核對 [既有成功發布紀錄](https://github.com/ntustRay/engineer-stock-data/actions/runs/41200225595)。本次查到的這筆 run 為 success；沒有把它當成本次重新發布的結果。

## 5. 到 data branch 核對結果

切換 branch 為 `data`，開 `manifest.json`，核對 `latestTradingDate`、`snapshotId`、`counts`。再確認網站的資料日期。

本專案以新的 root commit 替換 `data`，只保留一個可達版本；GitHub 不保證立即清除不可達 objects。要研究歷史變化，需另外保存快照。

## 6. 自己判讀一次失敗

先看最後一個通過的階段，再對照：

| 卡住位置 | 查哪裡 |
| --- | --- |
| validate | unit test、Biome 或 TypeScript 的第一個錯誤 |
| 來源讀取／日期 | `config/sources.yml`、交易日曆、來源實際日期 |
| 快照驗證 | `src/verify.ts`、manifest 的 hash 與資料期間 |
| push lease | 是否已有人發布另一版；先重新讀取遠端版本 |

確認失敗時 `data` 的 SHA 沒有被換掉，再修正原因。完整資料檢查在 `verify-data.yml`；它與「抓新資料」是不同任務。

[下載系列程式片段、圖片與驗證紀錄](../README.md)

## 參考資料

- [資料 Pipeline（本文對照版本）](https://github.com/ntustRay/engineer-stock-data/tree/c1633aeffe68d4ad95e88ea403d1bfbc1585f70e)
- [GitHub Workflow events](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows)
- [已核對的 Publish data run](https://github.com/ntustRay/engineer-stock-data/actions/runs/41200225595)

[回離線目錄](../README.md) · [上一章](./engineer-stock-02-json.md) · [下一章](./engineer-stock-04-nextjs-data.md)
